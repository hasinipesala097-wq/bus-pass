import React, { useState } from 'react';
import { PassApplication } from '../types';
import {
  CreditCard,
  QrCode,
  Building,
  ShieldCheck,
  CheckCircle2,
  X,
  Lock,
  ArrowRight,
  Smartphone
} from 'lucide-react';

interface PaymentModalProps {
  application: PassApplication;
  onPaymentSuccess: (transactionId: string, paymentMethod: string) => void;
  onClose: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  application,
  onPaymentSuccess,
  onClose
}) => {
  const [method, setMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [upiId, setUpiId] = useState('student@okaxis');
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8821');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [generatedTxn, setGeneratedTxn] = useState('');

  const handlePay = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const txn = 'TXN-' + Math.floor(100000000 + Math.random() * 900000000);
      setGeneratedTxn(txn);
      setIsProcessing(false);
      setIsSuccess(true);

      const methodLabel =
        method === 'upi' ? `UPI (${upiId})` : method === 'card' ? 'Debit/Credit Card' : 'Net Banking';
      onPaymentSuccess(txn, methodLabel);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-900 to-indigo-800 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-white">
              <Lock size={18} />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Secure Fee Checkout</h3>
              <p className="text-xs text-indigo-200">College Transport Payment Portal</p>
            </div>
          </div>
          {!isProcessing && (
            <button
              onClick={onClose}
              className="p-1.5 text-indigo-200 hover:text-white hover:bg-white/10 rounded-lg transition"
            >
              <X size={18} />
            </button>
          )}
        </div>

        {/* Content */}
        <div className="p-6">
          {!isSuccess ? (
            <div className="space-y-5">
              {/* Fee Summary */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
                <div className="flex justify-between items-center text-xs text-slate-500 mb-1">
                  <span>Route & Pass Type</span>
                  <span className="font-semibold text-slate-800">
                    {application.routeNumber} • 1 Semester
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-500 mb-3">
                  <span>Student Name</span>
                  <span className="font-semibold text-slate-800">{application.studentName}</span>
                </div>
                <div className="border-t border-slate-200 pt-3 flex justify-between items-center">
                  <span className="font-bold text-sm text-slate-900">Total Payable Amount</span>
                  <span className="font-black text-2xl text-indigo-600">
                    ₹{application.feeAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Payment Methods */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Select Payment Option
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setMethod('upi')}
                    className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition text-xs font-semibold ${
                      method === 'upi'
                        ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 ring-2 ring-indigo-600/20'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Smartphone size={18} className="text-indigo-600" />
                    <span>UPI / GPay</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMethod('card')}
                    className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition text-xs font-semibold ${
                      method === 'card'
                        ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 ring-2 ring-indigo-600/20'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <CreditCard size={18} className="text-indigo-600" />
                    <span>Cards</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMethod('netbanking')}
                    className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition text-xs font-semibold ${
                      method === 'netbanking'
                        ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 ring-2 ring-indigo-600/20'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Building size={18} className="text-indigo-600" />
                    <span>Net Banking</span>
                  </button>
                </div>
              </div>

              {/* Payment details input */}
              {method === 'upi' && (
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-600">Enter UPI ID / VPA</label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:border-indigo-600 focus:bg-white outline-none"
                    placeholder="username@okhdfcbank"
                  />
                  <div className="flex gap-2 text-[11px] text-slate-500 pt-1">
                    <span className="bg-slate-100 px-2 py-0.5 rounded cursor-pointer hover:bg-slate-200" onClick={() => setUpiId('student@okhdfcbank')}>Google Pay</span>
                    <span className="bg-slate-100 px-2 py-0.5 rounded cursor-pointer hover:bg-slate-200" onClick={() => setUpiId('student@ybl')}>PhonePe</span>
                    <span className="bg-slate-100 px-2 py-0.5 rounded cursor-pointer hover:bg-slate-200" onClick={() => setUpiId('student@paytm')}>Paytm</span>
                  </div>
                </div>
              )}

              {method === 'card' && (
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-600">Card Number</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm focus:border-indigo-600 focus:bg-white outline-none"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      defaultValue="12/28"
                      placeholder="MM/YY"
                      className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm outline-none"
                    />
                    <input
                      type="password"
                      defaultValue="777"
                      placeholder="CVV"
                      className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm outline-none"
                    />
                  </div>
                </div>
              )}

              {method === 'netbanking' && (
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-600">Select Bank</label>
                  <select className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm outline-none">
                    <option>HDFC Bank</option>
                    <option>State Bank of India (SBI)</option>
                    <option>ICICI Bank</option>
                    <option>Axis Bank</option>
                    <option>Kotak Mahindra Bank</option>
                  </select>
                </div>
              )}

              {/* Pay Button */}
              <button
                type="button"
                onClick={handlePay}
                disabled={isProcessing}
                className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition disabled:opacity-60"
              >
                {isProcessing ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Processing Payment...</span>
                  </>
                ) : (
                  <>
                    <span>Pay ₹{application.feeAmount.toLocaleString()} Now</span>
                    <ArrowRight size={16} />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500">
                <ShieldCheck size={14} className="text-emerald-600" />
                <span>256-Bit SSL Encrypted College Fee Portal</span>
              </div>
            </div>
          ) : (
            /* Success View */
            <div className="text-center py-4 space-y-4 animate-in fade-in zoom-in-95 duration-200">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 size={38} />
              </div>

              <div>
                <h4 className="text-xl font-black text-slate-900">Payment Successful!</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Your bus pass fee has been confirmed and recorded.
                </p>
              </div>

              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-left text-xs space-y-1.5 font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans">Transaction ID:</span>
                  <span className="font-bold text-indigo-600">{generatedTxn}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans">Amount Paid:</span>
                  <span className="font-bold text-slate-800">₹{application.feeAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-sans">Bus Pass Status:</span>
                  <span className="font-bold text-emerald-600 font-sans">ACTIVE & READY</span>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-md transition"
              >
                View Digital Bus Pass
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
