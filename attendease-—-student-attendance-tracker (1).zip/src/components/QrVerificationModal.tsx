import React, { useState } from 'react';
import { DigitalBusPass } from '../types';
import {
  QrCode,
  CheckCircle2,
  XCircle,
  Search,
  ShieldAlert,
  UserCheck,
  Bus,
  Calendar,
  MapPin,
  X,
  ScanLine
} from 'lucide-react';

interface QrVerificationModalProps {
  passes: DigitalBusPass[];
  onClose: () => void;
}

export const QrVerificationModal: React.FC<QrVerificationModalProps> = ({ passes, onClose }) => {
  const [searchInput, setSearchInput] = useState('');
  const [scannedResult, setScannedResult] = useState<{
    pass?: DigitalBusPass;
    isValid: boolean;
    reason?: string;
  } | null>(null);

  const handleVerify = (inputString: string) => {
    const query = inputString.trim();
    if (!query) return;

    // Check if input is a JSON string from QR code or pass ID
    let passId = query;
    try {
      if (query.startsWith('{') && query.endsWith('}')) {
        const parsed = JSON.parse(query);
        if (parsed.passId) {
          passId = parsed.passId;
        }
      }
    } catch {
      // not JSON, use query directly
    }

    const matched = passes.find(
      (p) =>
        p.id.toLowerCase() === passId.toLowerCase() ||
        p.rollNumber.toLowerCase() === passId.toLowerCase()
    );

    if (matched) {
      if (matched.status === 'active') {
        setScannedResult({ pass: matched, isValid: true });
      } else {
        setScannedResult({
          pass: matched,
          isValid: false,
          reason: `Pass is currently ${matched.status.toUpperCase()}`
        });
      }
    } else {
      setScannedResult({
        isValid: false,
        reason: 'No registered pass found matching this QR code or ID.'
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/60 border border-indigo-400/30 flex items-center justify-center text-white">
              <ScanLine size={22} className="animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Conductor QR Pass Verifier</h3>
              <p className="text-xs text-indigo-200">Scan or verify digital student bus passes</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Input Box */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              Scan QR Payload or Enter Pass ID / Roll No
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="e.g. PASS-2026-8901 or 22CS089"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleVerify(searchInput);
                  }}
                  className="w-full bg-slate-50 border border-slate-300 focus:border-indigo-600 focus:bg-white text-sm rounded-xl px-4 py-2.5 outline-none transition"
                />
              </div>
              <button
                onClick={() => handleVerify(searchInput)}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl flex items-center gap-2 shadow-sm transition"
              >
                <Search size={16} /> Verify
              </button>
            </div>
          </div>

          {/* Quick simulation buttons */}
          <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
              Quick Test Samples
            </span>
            <div className="flex flex-wrap gap-2">
              {passes.slice(0, 2).map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    setSearchInput(p.id);
                    handleVerify(p.id);
                  }}
                  className="text-xs bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200 font-medium transition"
                >
                  ✓ Pass: {p.id} ({p.studentName.split(' ')[0]})
                </button>
              ))}
              <button
                onClick={() => {
                  setSearchInput('FAKE-PASS-9999');
                  handleVerify('FAKE-PASS-9999');
                }}
                className="text-xs bg-white hover:bg-red-50 hover:text-red-700 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200 font-medium transition"
              >
                ✕ Test Invalid Pass
              </button>
            </div>
          </div>

          {/* Scanned Result Card */}
          {scannedResult && (
            <div
              className={`rounded-2xl p-4 border animate-in fade-in duration-200 ${
                scannedResult.isValid
                  ? 'bg-emerald-50/80 border-emerald-300'
                  : 'bg-red-50/80 border-red-300'
              }`}
            >
              <div className="flex items-start gap-3">
                {scannedResult.isValid ? (
                  <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-md">
                    <CheckCircle2 size={24} />
                  </div>
                ) : (
                  <div className="p-2 bg-red-600 text-white rounded-xl shadow-md">
                    <XCircle size={24} />
                  </div>
                )}

                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4
                      className={`font-black text-sm uppercase tracking-wider ${
                        scannedResult.isValid ? 'text-emerald-800' : 'text-red-800'
                      }`}
                    >
                      {scannedResult.isValid ? 'PASS VERIFIED & ACTIVE' : 'VERIFICATION FAILED'}
                    </h4>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        scannedResult.isValid
                          ? 'bg-emerald-200 text-emerald-900'
                          : 'bg-red-200 text-red-900'
                      }`}
                    >
                      {scannedResult.isValid ? 'AUTHORISED' : 'DENIED'}
                    </span>
                  </div>

                  {scannedResult.isValid && scannedResult.pass && (
                    <div className="mt-3 space-y-2">
                      <div className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-emerald-200 shadow-sm">
                        <img
                          src={scannedResult.pass.photoUrl}
                          alt={scannedResult.pass.studentName}
                          className="w-12 h-14 object-cover rounded-lg border border-slate-200"
                        />
                        <div>
                          <div className="font-bold text-slate-900 text-sm">
                            {scannedResult.pass.studentName}
                          </div>
                          <div className="text-xs text-slate-500 font-mono">
                            Roll: {scannedResult.pass.rollNumber} • {scannedResult.pass.department}
                          </div>
                          <div className="text-[11px] text-emerald-700 font-semibold">
                            Pass #{scannedResult.pass.id}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                        <div className="bg-white/80 p-2 rounded-lg border border-emerald-100">
                          <span className="text-[10px] text-slate-500 block">Assigned Bus</span>
                          <span className="font-bold text-slate-800">
                            {scannedResult.pass.routeNumber} ({scannedResult.pass.busNumber})
                          </span>
                        </div>
                        <div className="bg-white/80 p-2 rounded-lg border border-emerald-100">
                          <span className="text-[10px] text-slate-500 block">Boarding Stop</span>
                          <span className="font-bold text-slate-800 truncate block">
                            {scannedResult.pass.stopName}
                          </span>
                        </div>
                      </div>

                      <div className="text-[11px] text-slate-600 flex items-center gap-1.5 pt-1">
                        <Calendar size={13} className="text-emerald-600" />
                        <span>Valid until: <b>{scannedResult.pass.validUntil}</b></span>
                      </div>
                    </div>
                  )}

                  {!scannedResult.isValid && (
                    <p className="mt-1 text-xs text-red-700 leading-relaxed font-medium">
                      {scannedResult.reason || 'Invalid QR code signature or record not found.'}
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold text-xs rounded-xl transition"
          >
            Close Scanner
          </button>
        </div>
      </div>
    </div>
  );
};
