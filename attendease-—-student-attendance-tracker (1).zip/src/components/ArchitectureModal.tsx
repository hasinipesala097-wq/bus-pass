import React, { useState } from 'react';
import { Database, FileCode, Check, Copy, BookOpen, Layers, Terminal, X } from 'lucide-react';

interface ArchitectureModalProps {
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'diagram' | 'mongoose' | 'sql' | 'guide'>('diagram');
  const [copied, setCopied] = useState(false);

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const mongooseCode = `// MongoDB Mongoose Schemas & Relationships
const mongoose = require('mongoose');

// 1. User Schema (Student & Admin)
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['student', 'admin'], default: 'student' },
  rollNumber: { type: String }, // e.g. '22CS089'
  department: { type: String },
  year: { type: String },
  phone: { type: String },
  avatar: { type: String }
}, { timestamps: true });

// 2. Route & Bus Fleet Schema
const StopSchema = new mongoose.Schema({
  name: { type: String, required: true },
  pickupTime: { type: String, required: true },
  dropTime: { type: String, required: true },
  landmark: { type: String }
});

const RouteSchema = new mongoose.Schema({
  routeNumber: { type: String, required: true, unique: true }, // 'R-01'
  name: { type: String, required: true },
  busNumber: { type: String, required: true },
  driverName: { type: String, required: true },
  driverPhone: { type: String, required: true },
  morningDeparture: { type: String, required: true },
  eveningDeparture: { type: String, required: true },
  capacity: { type: Number, required: true, default: 45 },
  fee: { type: Number, required: true },
  stops: [StopSchema]
}, { timestamps: true });

// 3. Pass Application Schema (Relates User & Route)
const ApplicationSchema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  routeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Route', required: true },
  stopName: { type: String, required: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  feeStatus: { type: String, enum: ['paid', 'unpaid'], default: 'unpaid' },
  feeAmount: { type: Number, required: true },
  paymentMethod: { type: String },
  transactionId: { type: String },
  appliedAt: { type: Date, default: Date.now },
  approvedAt: { type: Date },
  adminRemarks: { type: String }
});

// 4. Digital Bus Pass Schema (Cryptographic QR & Validity)
const DigitalPassSchema = new mongoose.Schema({
  applicationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Application', required: true },
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  passNumber: { type: String, required: true, unique: true }, // 'PASS-2026-8901'
  routeNumber: { type: String, required: true },
  busNumber: { type: String, required: true },
  stopName: { type: String, required: true },
  issueDate: { type: Date, default: Date.now },
  validUntil: { type: Date, required: true },
  status: { type: String, enum: ['active', 'revoked', 'expired'], default: 'active' },
  qrPayload: { type: String, required: true }
});

module.exports = {
  User: mongoose.model('User', UserSchema),
  Route: mongoose.model('Route', RouteSchema),
  Application: mongoose.model('Application', ApplicationSchema),
  DigitalPass: mongoose.model('DigitalPass', DigitalPassSchema)
};`;

  const sqlCode = `-- Relational Schema (PostgreSQL / MySQL)

-- 1. Users Table
CREATE TABLE users (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('student', 'admin')),
    roll_number VARCHAR(30),
    department VARCHAR(80),
    academic_year VARCHAR(30),
    phone VARCHAR(20),
    avatar_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Bus Routes Table
CREATE TABLE bus_routes (
    id VARCHAR(36) PRIMARY KEY,
    route_number VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    bus_number VARCHAR(30) NOT NULL,
    driver_name VARCHAR(100) NOT NULL,
    driver_phone VARCHAR(20) NOT NULL,
    morning_departure VARCHAR(20) NOT NULL,
    evening_departure VARCHAR(20) NOT NULL,
    capacity INT NOT NULL DEFAULT 45,
    fee NUMERIC(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Route Stops Table (1-to-Many with Routes)
CREATE TABLE route_stops (
    id VARCHAR(36) PRIMARY KEY,
    route_id VARCHAR(36) NOT NULL REFERENCES bus_routes(id) ON DELETE CASCADE,
    stop_name VARCHAR(100) NOT NULL,
    pickup_time VARCHAR(20) NOT NULL,
    drop_time VARCHAR(20) NOT NULL,
    stop_order INT NOT NULL
);

-- 4. Pass Applications Table (Many-to-1 with Users & Routes)
CREATE TABLE pass_applications (
    id VARCHAR(36) PRIMARY KEY,
    student_id VARCHAR(36) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    route_id VARCHAR(36) NOT NULL REFERENCES bus_routes(id),
    stop_name VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    fee_status VARCHAR(20) NOT NULL DEFAULT 'unpaid' CHECK (fee_status IN ('paid', 'unpaid')),
    fee_amount NUMERIC(10, 2) NOT NULL,
    transaction_id VARCHAR(100),
    payment_method VARCHAR(50),
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP,
    admin_remarks TEXT
);

-- 5. Digital Bus Passes Table (QR verification)
CREATE TABLE digital_bus_passes (
    id VARCHAR(36) PRIMARY KEY, -- e.g. 'PASS-2026-8901'
    application_id VARCHAR(36) NOT NULL REFERENCES pass_applications(id),
    student_id VARCHAR(36) NOT NULL REFERENCES users(id),
    route_number VARCHAR(20) NOT NULL,
    bus_number VARCHAR(30) NOT NULL,
    stop_name VARCHAR(100) NOT NULL,
    issue_date DATE NOT NULL,
    valid_until DATE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revoked', 'expired')),
    qr_payload TEXT NOT NULL
);`;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] shadow-2xl flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/50 border border-indigo-400/30 flex items-center justify-center">
              <Database size={22} className="text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Database Schema & System Architecture</h3>
              <p className="text-xs text-indigo-200">
                Entity relationships, models, and local execution guide
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="bg-slate-100 border-b border-slate-200 p-2 flex gap-2">
          <button
            onClick={() => setActiveTab('diagram')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'diagram'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers size={14} /> Schema Relationships
          </button>
          <button
            onClick={() => setActiveTab('mongoose')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'mongoose'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileCode size={14} /> MongoDB Schemas
          </button>
          <button
            onClick={() => setActiveTab('sql')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'sql'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database size={14} /> MySQL / Postgres DDL
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'guide'
                ? 'bg-white text-indigo-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Terminal size={14} /> VS Code Setup Guide
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
          {activeTab === 'diagram' && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <h4 className="font-bold text-slate-900 text-sm mb-3">
                  Entity Relationship Flow (ER Diagram Overview)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
                  {/* Entity 1 */}
                  <div className="bg-indigo-50/70 border border-indigo-200 rounded-xl p-3.5 space-y-2">
                    <div className="font-extrabold text-indigo-900 uppercase tracking-wider flex items-center justify-between">
                      <span>Users</span>
                      <span className="text-[10px] bg-indigo-200 text-indigo-900 px-1.5 py-0.5 rounded">Entity</span>
                    </div>
                    <ul className="text-slate-600 space-y-1 font-mono text-[11px]">
                      <li>• id (PK)</li>
                      <li>• name</li>
                      <li>• email (Unique)</li>
                      <li>• role (student/admin)</li>
                      <li>• rollNumber</li>
                      <li>• department</li>
                    </ul>
                    <div className="text-[10px] text-indigo-600 font-semibold pt-1">
                      1 ──► Many Applications
                    </div>
                  </div>

                  {/* Entity 2 */}
                  <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-3.5 space-y-2">
                    <div className="font-extrabold text-purple-900 uppercase tracking-wider flex items-center justify-between">
                      <span>Bus Routes</span>
                      <span className="text-[10px] bg-purple-200 text-purple-900 px-1.5 py-0.5 rounded">Entity</span>
                    </div>
                    <ul className="text-slate-600 space-y-1 font-mono text-[11px]">
                      <li>• id (PK)</li>
                      <li>• routeNumber (R-01)</li>
                      <li>• busNumber</li>
                      <li>• driverName & Phone</li>
                      <li>• capacity (e.g. 45)</li>
                      <li>• feeAmount</li>
                    </ul>
                    <div className="text-[10px] text-purple-600 font-semibold pt-1">
                      1 ──► Many Stops & Passes
                    </div>
                  </div>

                  {/* Entity 3 */}
                  <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3.5 space-y-2">
                    <div className="font-extrabold text-amber-900 uppercase tracking-wider flex items-center justify-between">
                      <span>Applications</span>
                      <span className="text-[10px] bg-amber-200 text-amber-900 px-1.5 py-0.5 rounded">Relation</span>
                    </div>
                    <ul className="text-slate-600 space-y-1 font-mono text-[11px]">
                      <li>• id (PK)</li>
                      <li>• studentId (FK)</li>
                      <li>• routeId (FK)</li>
                      <li>• stopName</li>
                      <li>• status (pending/appr)</li>
                      <li>• feeStatus (paid/unpaid)</li>
                    </ul>
                    <div className="text-[10px] text-amber-600 font-semibold pt-1">
                      Approved + Paid ──► Pass
                    </div>
                  </div>

                  {/* Entity 4 */}
                  <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3.5 space-y-2">
                    <div className="font-extrabold text-emerald-900 uppercase tracking-wider flex items-center justify-between">
                      <span>Digital Passes</span>
                      <span className="text-[10px] bg-emerald-200 text-emerald-900 px-1.5 py-0.5 rounded">Token</span>
                    </div>
                    <ul className="text-slate-600 space-y-1 font-mono text-[11px]">
                      <li>• id (PASS-2026-X)</li>
                      <li>• applicationId (FK)</li>
                      <li>• studentId (FK)</li>
                      <li>• qrPayload (JSON)</li>
                      <li>• validUntil (Date)</li>
                      <li>• status (active)</li>
                    </ul>
                    <div className="text-[10px] text-emerald-600 font-semibold pt-1">
                      Verified by Conductor QR
                    </div>
                  </div>
                </div>
              </div>

              {/* Core Business Rules */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <h4 className="font-bold text-slate-900 text-sm">Key System Rules Implemented:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-600">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <b className="text-slate-800 block mb-1">1. Overcrowding Prevention:</b>
                    Each route has a maximum seat capacity (e.g. 45). The dashboard tracks real-time approved passes vs capacity. When &gt;85% is reached, an alert triggers and prevents over-allocation.
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <b className="text-slate-800 block mb-1">2. Two-Step Pass Generation:</b>
                    Admin reviews and approves application first. Once approved, the student completes mock payment, which automatically issues a cryptographic QR pass.
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <b className="text-slate-800 block mb-1">3. Conductor QR Verification:</b>
                    Conductors use the in-app scanner to verify passes in offline or online scenarios by decoding the pass ID and verifying validity.
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                    <b className="text-slate-800 block mb-1">4. Gemini AI Transport Assistant:</b>
                    Integrated floating chatbot equipped with full route timing, fee schedules, stop tables, and college transport guidelines.
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'mongoose' && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-600">Mongoose / Node.js Models</span>
                <button
                  onClick={() => copyToClipboard(mongooseCode)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition"
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  <span>{copied ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>
              <pre className="bg-slate-950 text-slate-200 p-4 rounded-2xl text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                {mongooseCode}
              </pre>
            </div>
          )}

          {activeTab === 'sql' && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-600">PostgreSQL / MySQL DDL Scripts</span>
                <button
                  onClick={() => copyToClipboard(sqlCode)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition"
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  <span>{copied ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>
              <pre className="bg-slate-950 text-slate-200 p-4 rounded-2xl text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                {sqlCode}
              </pre>
            </div>
          )}

          {activeTab === 'guide' && (
            <div className="space-y-4 text-xs text-slate-700">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <h4 className="font-bold text-slate-900 text-sm">
                  Step-by-Step Instructions to Run Locally in VS Code:
                </h4>
                <ol className="space-y-3 list-decimal list-inside leading-relaxed text-slate-600">
                  <li>
                    <strong className="text-slate-800">Prerequisites:</strong> Ensure you have <b>Node.js (v18+)</b> and <b>npm</b> installed on your computer.
                  </li>
                  <li>
                    <strong className="text-slate-800">Open Project in VS Code:</strong>
                    <div className="bg-slate-900 text-emerald-400 p-2.5 rounded-xl font-mono text-[11px] mt-1.5">
                      cd college-bus-pass-system<br />
                      code .
                    </div>
                  </li>
                  <li>
                    <strong className="text-slate-800">Install Dependencies:</strong> Run in the VS Code terminal:
                    <div className="bg-slate-900 text-emerald-400 p-2.5 rounded-xl font-mono text-[11px] mt-1.5">
                      npm install
                    </div>
                  </li>
                  <li>
                    <strong className="text-slate-800">Environment Variables:</strong> Create a <code className="bg-slate-100 px-1 py-0.5 rounded">.env</code> file in the project root:
                    <div className="bg-slate-900 text-emerald-400 p-2.5 rounded-xl font-mono text-[11px] mt-1.5">
                      GEMINI_API_KEY="your-gemini-api-key-here"<br />
                      PORT=3000
                    </div>
                  </li>
                  <li>
                    <strong className="text-slate-800">Start the Full-Stack Server:</strong>
                    <div className="bg-slate-900 text-emerald-400 p-2.5 rounded-xl font-mono text-[11px] mt-1.5">
                      npm run dev
                    </div>
                  </li>
                  <li>
                    <strong className="text-slate-800">Access the Application:</strong> Open your browser to <code className="bg-slate-100 px-1 py-0.5 rounded font-bold text-indigo-700">http://localhost:3000</code>.
                  </li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-sm transition"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
