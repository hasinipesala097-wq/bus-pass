import React, { useEffect, useState, useRef } from 'react';
import { DigitalBusPass } from '../types';
import { generateQrDataUrl } from '../services/store';
import {
  Download,
  Printer,
  ShieldCheck,
  Bus,
  MapPin,
  Calendar,
  CheckCircle,
  Share2
} from 'lucide-react';

interface DigitalPassCardProps {
  pass: DigitalBusPass;
  onClose?: () => void;
}

export const DigitalPassCard: React.FC<DigitalPassCardProps> = ({ pass, onClose }) => {
  const [qrUrl, setQrUrl] = useState<string>('');
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    generateQrDataUrl(pass.qrData).then((url) => {
      setQrUrl(url);
    });
  }, [pass]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadImage = () => {
    // Simple prompt or print view for saving as PDF
    window.print();
  };

  return (
    <div className="flex flex-col items-center max-w-md mx-auto">
      {/* Printable ID Card Container */}
      <div
        ref={cardRef}
        className="w-full bg-gradient-to-b from-slate-900 to-indigo-950 text-white rounded-3xl p-5 shadow-2xl border-2 border-indigo-500/30 relative overflow-hidden print:shadow-none print:border print:border-black"
      >
        {/* Hologram Accent Effect */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-gradient-to-br from-indigo-500/20 via-purple-500/30 to-pink-500/20 rounded-full blur-2xl pointer-events-none"></div>
        <div className="absolute -bottom-10 -left-10 w-36 h-36 bg-emerald-500/20 rounded-full blur-2xl pointer-events-none"></div>

        {/* College Header */}
        <div className="border-b border-indigo-400/20 pb-3 mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center font-black text-xl tracking-wider text-white shadow-md">
              <Bus size={22} />
            </div>
            <div>
              <h3 className="font-extrabold text-sm uppercase tracking-wider text-indigo-100">
                City Engineering College
              </h3>
              <p className="text-[10px] text-indigo-300 font-semibold tracking-widest uppercase">
                Transport Department • Student Bus Pass
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="inline-flex items-center gap-1 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-bold px-2 py-0.5 rounded-full">
              <ShieldCheck size={11} /> {pass.status.toUpperCase()}
            </span>
          </div>
        </div>

        {/* Main Body */}
        <div className="grid grid-cols-12 gap-4 items-center">
          {/* Photo */}
          <div className="col-span-4 flex flex-col items-center">
            <div className="relative">
              <img
                src={pass.photoUrl}
                alt={pass.studentName}
                className="w-24 h-28 object-cover rounded-xl border-2 border-indigo-400/60 shadow-lg bg-slate-800"
              />
              <span className="absolute -bottom-2 bg-indigo-600 text-[9px] font-mono font-bold px-2 py-0.5 rounded-full text-indigo-100 uppercase tracking-tighter">
                {pass.rollNumber}
              </span>
            </div>
          </div>

          {/* Student Info */}
          <div className="col-span-8 space-y-1.5 pl-1">
            <div>
              <span className="text-[10px] uppercase text-indigo-300 font-semibold">Student Name</span>
              <h4 className="font-bold text-base text-white leading-tight">{pass.studentName}</h4>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[9px] uppercase text-indigo-300 font-semibold block">Department</span>
                <span className="font-medium text-slate-200 text-[11px] truncate block">{pass.department}</span>
              </div>
              <div>
                <span className="text-[9px] uppercase text-indigo-300 font-semibold block">Academic Year</span>
                <span className="font-medium text-slate-200 text-[11px] block">{pass.year}</span>
              </div>
            </div>

            <div>
              <span className="text-[9px] uppercase text-indigo-300 font-semibold block">Pass Number</span>
              <span className="font-mono text-amber-300 font-bold text-xs">{pass.id}</span>
            </div>
          </div>
        </div>

        {/* Route Details Card Inside Pass */}
        <div className="mt-4 bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="bg-indigo-600 text-white font-extrabold text-xs px-2.5 py-1 rounded-lg">
                {pass.routeNumber}
              </span>
              <span className="font-bold text-sm text-indigo-100">{pass.routeName}</span>
            </div>
            <span className="text-[11px] font-mono text-amber-300 bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/20 font-semibold">
              Bus {pass.busNumber}
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-200">
            <MapPin size={13} className="text-pink-400 flex-shrink-0" />
            <span className="text-[11px]">
              Boarding Stop: <b className="text-white">{pass.stopName}</b>
            </span>
          </div>
        </div>

        {/* Bottom Section: QR Code & Validity */}
        <div className="mt-4 pt-3 border-t border-indigo-400/20 flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
              <Calendar size={12} className="text-indigo-400" />
              <span>Valid Thru: <b className="text-emerald-300">{pass.validUntil}</b></span>
            </div>
            <p className="text-[9px] text-indigo-300/80">
              Show QR code to conductor upon boarding
            </p>
          </div>

          {/* Dynamic Generated QR Code */}
          <div className="bg-white p-1.5 rounded-xl shadow-lg border border-slate-200">
            {qrUrl ? (
              <img src={qrUrl} alt="Pass QR Code" className="w-16 h-16 object-contain" />
            ) : (
              <div className="w-16 h-16 bg-slate-200 animate-pulse rounded-lg"></div>
            )}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-3 mt-4 print:hidden">
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 text-xs font-semibold shadow-md transition"
        >
          <Printer size={15} /> Print Pass
        </button>
        <button
          onClick={handleDownloadImage}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 text-xs font-semibold shadow-md transition"
        >
          <Download size={15} /> Save / PDF
        </button>
        {onClose && (
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-200 text-slate-700 hover:bg-slate-300 text-xs font-semibold transition"
          >
            Close
          </button>
        )}
      </div>
    </div>
  );
};
