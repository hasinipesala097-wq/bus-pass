import React, { useState, useEffect, useMemo } from 'react';
import {
  Bus,
  ShieldCheck,
  QrCode,
  Users,
  CreditCard,
  AlertTriangle,
  Clock,
  MapPin,
  CheckCircle2,
  XCircle,
  Plus,
  Search,
  Filter,
  FileText,
  LogOut,
  Sparkles,
  Phone,
  User,
  Layers,
  ChevronRight,
  Eye,
  Check,
  Calendar,
  AlertCircle,
  Download,
  Printer
} from 'lucide-react';
import {
  User as UserType,
  BusRoute,
  PassApplication,
  DigitalBusPass,
  Stop
} from './types';
import {
  INITIAL_USERS,
  INITIAL_ROUTES,
  INITIAL_APPLICATIONS,
  INITIAL_PASSES
} from './services/store';
import { AiChatbot } from './components/AiChatbot';
import { DigitalPassCard } from './components/DigitalPassCard';
import { QrVerificationModal } from './components/QrVerificationModal';
import { PaymentModal } from './components/PaymentModal';
import { ArchitectureModal } from './components/ArchitectureModal';

const STORAGE_KEY_DATA = 'campusPassData_v2';

export default function App() {
  // Database States
  const [users, setUsers] = useState<UserType[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_DATA + '_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [routes, setRoutes] = useState<BusRoute[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_DATA + '_routes');
    return saved ? JSON.parse(saved) : INITIAL_ROUTES;
  });

  const [applications, setApplications] = useState<PassApplication[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_DATA + '_applications');
    return saved ? JSON.parse(saved) : INITIAL_APPLICATIONS;
  });

  const [passes, setPasses] = useState<DigitalBusPass[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_DATA + '_passes');
    return saved ? JSON.parse(saved) : INITIAL_PASSES;
  });

  // Current session
  const [currentUser, setCurrentUser] = useState<UserType | null>(() => {
    return INITIAL_USERS[1]; // default student Aarav Sharma for quick preview
  });

  // UI state
  const [activeTab, setActiveTab] = useState<'overview' | 'apply' | 'pass' | 'routes' | 'applications' | 'fleet'>('overview');
  const [showQrModal, setShowQrModal] = useState(false);
  const [showArchModal, setShowArchModal] = useState(false);
  const [payingApplication, setPayingApplication] = useState<PassApplication | null>(null);
  const [viewingPass, setViewingPass] = useState<DigitalBusPass | null>(null);
  const [showAddRouteModal, setShowAddRouteModal] = useState(false);

  // Login/Signup form
  const [isAuthMode, setIsAuthMode] = useState<'login' | 'signup'>('login');
  const [authRole, setAuthRole] = useState<'student' | 'admin'>('student');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [authRoll, setAuthRoll] = useState('');
  const [authDept, setAuthDept] = useState('Computer Science & Engg');
  const [authYear, setAuthYear] = useState('3rd Year (VI Sem)');
  const [authPhone, setAuthPhone] = useState('');
  const [authError, setAuthError] = useState('');

  // Apply form state
  const [applyRouteId, setApplyRouteId] = useState<string>(routes[0]?.id || '');
  const [applyStopId, setApplyStopId] = useState<string>(routes[0]?.stops[0]?.id || '');
  const [applySuccess, setApplySuccess] = useState(false);

  // New Route form state
  const [newRouteNum, setNewRouteNum] = useState('');
  const [newRouteName, setNewRouteName] = useState('');
  const [newBusNum, setNewBusNum] = useState('');
  const [newDriverName, setNewDriverName] = useState('');
  const [newDriverPhone, setNewDriverPhone] = useState('');
  const [newCapacity, setNewCapacity] = useState('45');
  const [newFee, setNewFee] = useState('14000');
  const [newMorning, setNewMorning] = useState('07:15 AM');
  const [newEvening, setNewEvening] = useState('04:45 PM');
  const [newStopsText, setNewStopsText] = useState('Stop 1 (7:15 AM), Stop 2 (7:30 AM), College Gate (8:20 AM)');

  // Filter state for admin applications
  const [appFilter, setAppFilter] = useState<'all' | 'pending' | 'approved' | 'rejected' | 'unpaid'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Persist to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_DATA + '_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_DATA + '_routes', JSON.stringify(routes));
  }, [routes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_DATA + '_applications', JSON.stringify(applications));
  }, [applications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_DATA + '_passes', JSON.stringify(passes));
  }, [passes]);

  // Sync default stops when applyRouteId changes
  useEffect(() => {
    const selected = routes.find((r) => r.id === applyRouteId);
    if (selected && selected.stops.length > 0) {
      setApplyStopId(selected.stops[0].id);
    }
  }, [applyRouteId, routes]);

  // Capacity calculation per route
  const routeOccupancy = useMemo(() => {
    const map: Record<string, { count: number; capacity: number; pct: number }> = {};
    routes.forEach((r) => {
      // count approved applications or active passes for this route
      const enrolled = applications.filter(
        (a) => a.routeId === r.id && (a.status === 'approved' || a.status === 'pending')
      ).length;
      const pct = Math.round((enrolled / r.capacity) * 100);
      map[r.id] = { count: enrolled, capacity: r.capacity, pct };
    });
    return map;
  }, [routes, applications]);

  // Any route with capacity alert (>85%)
  const highCapacityRoutes = useMemo(() => {
    return routes.filter((r) => {
      const stats = routeOccupancy[r.id];
      return stats && stats.pct >= 85;
    });
  }, [routes, routeOccupancy]);

  // Current student's application & pass
  const myApplication = useMemo(() => {
    if (!currentUser || currentUser.role !== 'student') return null;
    return applications.find((a) => a.studentId === currentUser.id);
  }, [currentUser, applications]);

  const myPass = useMemo(() => {
    if (!currentUser || currentUser.role !== 'student') return null;
    return passes.find((p) => p.studentId === currentUser.id && p.status === 'active');
  }, [currentUser, passes]);

  // Authentication Handlers
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    const user = users.find(
      (u) =>
        u.email.toLowerCase() === authEmail.trim().toLowerCase() &&
        u.password === authPassword.trim() &&
        u.role === authRole
    );
    if (user) {
      setCurrentUser(user);
      setActiveTab('overview');
    } else {
      setAuthError(`Invalid credentials for ${authRole}. Click demo buttons below to fill credentials.`);
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!authEmail || !authPassword || !authName) {
      setAuthError('Please fill in all mandatory fields.');
      return;
    }
    const exists = users.find((u) => u.email.toLowerCase() === authEmail.trim().toLowerCase());
    if (exists) {
      setAuthError('User with this email already exists.');
      return;
    }
    const newUser: UserType = {
      id: 'u-' + Date.now(),
      name: authName.trim(),
      email: authEmail.trim(),
      password: authPassword.trim(),
      role: authRole,
      rollNumber: authRole === 'student' ? authRoll.trim() : undefined,
      department: authRole === 'student' ? authDept : undefined,
      year: authRole === 'student' ? authYear : undefined,
      phone: authPhone.trim() || '+91 98000 00000',
      avatar:
        authRole === 'student'
          ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80'
    };
    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    setActiveTab('overview');
  };

  const quickSwitchUser = (email: string) => {
    const user = users.find((u) => u.email === email);
    if (user) {
      setCurrentUser(user);
      setActiveTab('overview');
    }
  };

  // Student Apply Handler
  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const selectedRoute = routes.find((r) => r.id === applyRouteId);
    const selectedStop = selectedRoute?.stops.find((s) => s.id === applyStopId);

    if (!selectedRoute || !selectedStop) return;

    // Check capacity before creating application
    const stats = routeOccupancy[selectedRoute.id];
    if (stats && stats.count >= stats.capacity) {
      alert(`Route ${selectedRoute.routeNumber} is at maximum capacity (${stats.capacity} seats). Please select another route or contact Transport Admin.`);
      return;
    }

    const newApp: PassApplication = {
      id: 'app-' + Date.now(),
      studentId: currentUser.id,
      studentName: currentUser.name,
      rollNumber: currentUser.rollNumber || '22CS999',
      department: currentUser.department || 'Engineering',
      year: currentUser.year || '2nd Year',
      phone: currentUser.phone || '+91 98765 00000',
      email: currentUser.email,
      photoUrl: currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      routeId: selectedRoute.id,
      routeNumber: selectedRoute.routeNumber,
      routeName: selectedRoute.name,
      busNumber: selectedRoute.busNumber,
      stopId: selectedStop.id,
      stopName: selectedStop.name,
      status: 'pending',
      feeStatus: 'unpaid',
      feeAmount: selectedRoute.fee,
      appliedAt: new Date().toISOString().slice(0, 10)
    };

    setApplications((prev) => [newApp, ...prev.filter((a) => a.studentId !== currentUser.id)]);
    setApplySuccess(true);
    setTimeout(() => {
      setApplySuccess(false);
      setActiveTab('overview');
    }, 1800);
  };

  // Admin Application Action
  const handleUpdateAppStatus = (appId: string, newStatus: 'approved' | 'rejected', remarks?: string) => {
    setApplications((prev) =>
      prev.map((a) => {
        if (a.id === appId) {
          return {
            ...a,
            status: newStatus,
            approvedAt: newStatus === 'approved' ? new Date().toISOString().slice(0, 10) : undefined,
            adminRemarks: remarks
          };
        }
        return a;
      })
    );
  };

  // Payment Success Handler
  const handlePaymentSuccess = (appId: string, txnId: string, methodLabel: string) => {
    let updatedApp: PassApplication | null = null;

    setApplications((prev) =>
      prev.map((a) => {
        if (a.id === appId) {
          const passId = 'PASS-2026-' + Math.floor(1000 + Math.random() * 9000);
          updatedApp = {
            ...a,
            feeStatus: 'paid',
            transactionId: txnId,
            paymentMethod: methodLabel,
            passId: passId
          };
          return updatedApp;
        }
        return a;
      })
    );

    // Create Digital Bus Pass
    if (updatedApp) {
      const app = updatedApp as PassApplication;
      const newPass: DigitalBusPass = {
        id: app.passId || 'PASS-2026-9041',
        applicationId: app.id,
        studentId: app.studentId,
        studentName: app.studentName,
        rollNumber: app.rollNumber,
        department: app.department,
        year: app.year,
        phone: app.phone,
        photoUrl: app.photoUrl,
        routeNumber: app.routeNumber,
        routeName: app.routeName,
        busNumber: app.busNumber,
        stopName: app.stopName,
        issueDate: new Date().toISOString().slice(0, 10),
        validUntil: '2027-03-31',
        status: 'active',
        qrData: JSON.stringify({
          passId: app.passId,
          student: app.studentName,
          roll: app.rollNumber,
          route: `${app.routeNumber} (${app.routeName})`,
          bus: app.busNumber,
          stop: app.stopName,
          validUntil: '2027-03-31',
          status: 'VERIFIED_ACTIVE'
        })
      };

      setPasses((prev) => [newPass, ...prev.filter((p) => p.studentId !== app.studentId)]);
    }
  };

  // Admin Add Route
  const handleAddRoute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRouteNum || !newRouteName || !newBusNum) return;

    // Parse stops text
    const parsedStops: Stop[] = newStopsText.split(',').map((item, idx) => {
      const trimmed = item.trim();
      return {
        id: 'stop-' + Date.now() + '-' + idx,
        name: trimmed,
        pickupTime: '07:30 AM',
        dropTime: '05:15 PM'
      };
    });

    const newR: BusRoute = {
      id: 'r' + Date.now(),
      routeNumber: newRouteNum.trim().toUpperCase(),
      name: newRouteName.trim(),
      busNumber: newBusNum.trim().toUpperCase(),
      driverName: newDriverName.trim() || 'Assigned Driver',
      driverPhone: newDriverPhone.trim() || '+91 98000 11111',
      morningDeparture: newMorning,
      eveningDeparture: newEvening,
      capacity: parseInt(newCapacity) || 45,
      fee: parseInt(newFee) || 14000,
      stops: parsedStops.length > 0 ? parsedStops : [
        { id: 's1', name: 'Main City Circle', pickupTime: '07:15 AM', dropTime: '05:30 PM' },
        { id: 's2', name: 'College Campus Gate', pickupTime: '08:20 AM', dropTime: '04:45 PM' }
      ]
    };

    setRoutes((prev) => [...prev, newR]);
    setShowAddRouteModal(false);
  };

  // Filtered applications
  const filteredApps = useMemo(() => {
    return applications.filter((a) => {
      if (appFilter === 'pending' && a.status !== 'pending') return false;
      if (appFilter === 'approved' && a.status !== 'approved') return false;
      if (appFilter === 'rejected' && a.status !== 'rejected') return false;
      if (appFilter === 'unpaid' && (a.status !== 'approved' || a.feeStatus !== 'unpaid')) return false;

      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          a.studentName.toLowerCase().includes(q) ||
          a.rollNumber.toLowerCase().includes(q) ||
          a.routeNumber.toLowerCase().includes(q) ||
          a.stopName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [applications, appFilter, searchQuery]);

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 font-sans pb-16">
      {/* Top Banner Navigation */}
      <header className="sticky top-0 z-40 bg-slate-900 text-white border-b border-slate-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('overview')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <Bus size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-tight text-white">CampusPass</span>
                <span className="bg-indigo-500/30 text-indigo-300 border border-indigo-400/20 text-[10px] font-mono uppercase px-2 py-0.5 rounded-full font-bold">
                  v2.4
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                College Bus Pass & Fleet Management System
              </p>
            </div>
          </div>

          {/* Center Capacity Warning Badge (if overcrowding detected) */}
          {highCapacityRoutes.length > 0 && (
            <div className="hidden md:flex items-center gap-2 bg-amber-500/20 border border-amber-500/30 text-amber-300 px-3 py-1 rounded-full text-xs font-semibold animate-pulse">
              <AlertTriangle size={14} />
              <span>
                {highCapacityRoutes.length} Route(s) near full capacity ({highCapacityRoutes.map((r) => r.routeNumber).join(', ')})
              </span>
            </div>
          )}

          {/* Action Buttons & User Menu */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setShowArchModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition border border-slate-700"
              title="View Database Architecture, Mongoose Schemas & SQL DDL"
            >
              <Layers size={14} className="text-indigo-400" />
              <span className="hidden sm:inline">Schema & Architecture</span>
            </button>

            <button
              onClick={() => setShowQrModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold transition shadow-sm"
              title="Conductor QR Code Scanner"
            >
              <QrCode size={14} />
              <span>Scan QR</span>
            </button>

            {currentUser ? (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-700">
                <div className="text-right hidden sm:block">
                  <div className="font-bold text-xs text-white leading-tight">
                    {currentUser.name.split(' ')[0]}
                  </div>
                  <span className="text-[10px] text-indigo-300 uppercase font-semibold">
                    {currentUser.role}
                  </span>
                </div>
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full border border-indigo-400 object-cover"
                />
                <button
                  onClick={() => setCurrentUser(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
                  title="Logout"
                >
                  <LogOut size={16} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setCurrentUser(INITIAL_USERS[1])}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition"
              >
                Sign In
              </button>
            )}
          </div>
        </div>

        {/* Subnav for Logged In User */}
        {currentUser && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between border-t border-slate-800 overflow-x-auto text-xs py-1">
            <div className="flex items-center gap-1 sm:gap-2">
              <button
                onClick={() => setActiveTab('overview')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                  activeTab === 'overview'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Dashboard
              </button>

              {currentUser.role === 'student' && (
                <>
                  <button
                    onClick={() => setActiveTab('apply')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                      activeTab === 'apply'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Apply for Pass
                  </button>
                  <button
                    onClick={() => setActiveTab('pass')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                      activeTab === 'pass'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    My Digital Pass
                  </button>
                </>
              )}

              {currentUser.role === 'admin' && (
                <>
                  <button
                    onClick={() => setActiveTab('applications')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 ${
                      activeTab === 'applications'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <span>Student Applications</span>
                    {applications.filter((a) => a.status === 'pending').length > 0 && (
                      <span className="bg-amber-500 text-slate-900 text-[10px] px-1.5 py-0.2 font-black rounded-full">
                        {applications.filter((a) => a.status === 'pending').length}
                      </span>
                    )}
                  </button>
                  <button
                    onClick={() => setActiveTab('fleet')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                      activeTab === 'fleet'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Fleet & Routes
                  </button>
                </>
              )}

              <button
                onClick={() => setActiveTab('routes')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                  activeTab === 'routes'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Route Schedules
              </button>
            </div>

            {/* Quick Demo Switcher */}
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <span className="hidden md:inline">Quick Switch:</span>
              <button
                onClick={() => quickSwitchUser('student@college.edu')}
                className={`px-2 py-0.5 rounded border transition ${
                  currentUser.email === 'student@college.edu'
                    ? 'border-indigo-400 text-indigo-300 bg-indigo-900/30'
                    : 'border-slate-700 hover:text-white'
                }`}
              >
                🎓 Student
              </button>
              <button
                onClick={() => quickSwitchUser('admin@transport.edu')}
                className={`px-2 py-0.5 rounded border transition ${
                  currentUser.email === 'admin@transport.edu'
                    ? 'border-indigo-400 text-indigo-300 bg-indigo-900/30'
                    : 'border-slate-700 hover:text-white'
                }`}
              >
                🛠️ Admin
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {/* If user is NOT logged in: Show Auth Screen */}
        {!currentUser && (
          <div className="max-w-md mx-auto my-8 bg-white rounded-3xl p-8 shadow-xl border border-slate-200">
            <div className="text-center mb-6">
              <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center text-white mx-auto shadow-md mb-3">
                <Bus size={30} />
              </div>
              <h2 className="text-2xl font-black text-slate-900">CampusPass Portal</h2>
              <p className="text-xs text-slate-500 mt-1">
                College Bus Pass & Fleet Allocation System
              </p>
            </div>

            {/* Role switch */}
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1.5 rounded-2xl mb-5">
              <button
                type="button"
                onClick={() => setAuthRole('student')}
                className={`py-2 text-xs font-bold rounded-xl transition ${
                  authRole === 'student'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                🎓 Student
              </button>
              <button
                type="button"
                onClick={() => setAuthRole('admin')}
                className={`py-2 text-xs font-bold rounded-xl transition ${
                  authRole === 'admin'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                🛠️ Transport Admin
              </button>
            </div>

            {/* Login / Signup Tabs */}
            <div className="flex border-b border-slate-200 mb-5">
              <button
                onClick={() => setIsAuthMode('login')}
                className={`flex-1 pb-2 text-xs font-bold transition border-b-2 ${
                  isAuthMode === 'login'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                Login
              </button>
              <button
                onClick={() => setIsAuthMode('signup')}
                className={`flex-1 pb-2 text-xs font-bold transition border-b-2 ${
                  isAuthMode === 'signup'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-400 hover:text-slate-600'
                }`}
              >
                New Account (Signup)
              </button>
            </div>

            <form onSubmit={isAuthMode === 'login' ? handleLogin : handleSignup} className="space-y-3.5">
              {isAuthMode === 'signup' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                    placeholder="e.g. Aarav Sharma"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:border-indigo-600 focus:bg-white outline-none"
                  />
                </div>
              )}

              {isAuthMode === 'signup' && authRole === 'student' && (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Roll Number</label>
                    <input
                      type="text"
                      required
                      value={authRoll}
                      onChange={(e) => setAuthRoll(e.target.value)}
                      placeholder="e.g. 22CS089"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:border-indigo-600 focus:bg-white outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Department</label>
                    <select
                      value={authDept}
                      onChange={(e) => setAuthDept(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-2 py-2.5 text-xs focus:border-indigo-600 focus:bg-white outline-none"
                    >
                      <option>Computer Science & Engg</option>
                      <option>Electronics & Comm</option>
                      <option>Mechanical Engg</option>
                      <option>Civil Engg</option>
                    </select>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  placeholder={authRole === 'student' ? 'student@college.edu' : 'admin@transport.edu'}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:border-indigo-600 focus:bg-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
                <input
                  type="password"
                  required
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:border-indigo-600 focus:bg-white outline-none"
                />
              </div>

              {authError && (
                <div className="bg-red-50 text-red-700 p-2.5 rounded-xl text-xs border border-red-200">
                  {authError}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl transition shadow-md shadow-indigo-600/20"
              >
                {isAuthMode === 'login' ? `Login as ${authRole.toUpperCase()}` : 'Create Account & Sign In'}
              </button>
            </form>

            {/* Quick Demo Fill Buttons */}
            <div className="mt-6 pt-5 border-t border-slate-200">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2 text-center">
                Instant Demo Access
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setAuthRole('student');
                    setAuthEmail('student@college.edu');
                    setAuthPassword('1234');
                    setIsAuthMode('login');
                  }}
                  className="p-2.5 bg-slate-50 hover:bg-indigo-50 border border-slate-200 rounded-xl text-left transition"
                >
                  <div className="font-bold text-slate-800">🎓 Student Login</div>
                  <div className="text-[10px] text-slate-500 font-mono">student@college.edu / 1234</div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setAuthRole('admin');
                    setAuthEmail('admin@transport.edu');
                    setAuthPassword('admin');
                    setIsAuthMode('login');
                  }}
                  className="p-2.5 bg-slate-50 hover:bg-indigo-50 border border-slate-200 rounded-xl text-left transition"
                >
                  <div className="font-bold text-slate-800">🛠️ Admin Login</div>
                  <div className="text-[10px] text-slate-500 font-mono">admin@transport.edu / admin</div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* LOGGED IN USER VIEWS */}
        {currentUser && (
          <div className="space-y-6">
            {/* OVERVIEW DASHBOARD */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Welcome Card & Live Overcrowding Banner */}
                <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
                  <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div>
                      <div className="inline-flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-full text-xs font-medium text-indigo-200 mb-2">
                        <Sparkles size={13} className="text-amber-400" />
                        <span>Academic Transport Season 2026-2027</span>
                      </div>
                      <h2 className="text-2xl sm:text-3xl font-black text-white">
                        Welcome, {currentUser.name}!
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl leading-relaxed">
                        {currentUser.role === 'student'
                          ? 'Manage your bus pass, check stop pickup schedules, track fee payment, and present your digital QR pass to conductors.'
                          : 'Monitor route passenger capacity, approve pending applications, and manage college fleet logistics in real-time.'}
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-2.5">
                      {currentUser.role === 'student' ? (
                        <>
                          <button
                            onClick={() => setActiveTab('apply')}
                            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2"
                          >
                            <Plus size={16} /> Apply for Bus Pass
                          </button>
                          {myPass && (
                            <button
                              onClick={() => {
                                setViewingPass(myPass);
                              }}
                              className="px-4 py-2.5 bg-white text-slate-900 hover:bg-slate-100 font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2"
                            >
                              <QrCode size={16} /> View Digital Pass
                            </button>
                          )}
                        </>
                      ) : (
                        <>
                          <button
                            onClick={() => setShowAddRouteModal(true)}
                            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2"
                          >
                            <Plus size={16} /> Add Bus Route
                          </button>
                          <button
                            onClick={() => setActiveTab('applications')}
                            className="px-4 py-2.5 bg-white text-slate-900 hover:bg-slate-100 font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2"
                          >
                            <FileText size={16} /> Review Applications ({applications.filter((a) => a.status === 'pending').length})
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Overcrowding / Live Capacity Warning Alert Card */}
                {highCapacityRoutes.length > 0 && (
                  <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 text-amber-900 flex items-start gap-3 shadow-sm">
                    <div className="p-2 bg-amber-500 text-white rounded-xl flex-shrink-0">
                      <AlertTriangle size={22} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-extrabold text-sm text-amber-900">
                        Live Capacity Warning: Overcrowding Risk Detected
                      </h4>
                      <p className="text-xs text-amber-800 mt-0.5 leading-relaxed">
                        The following routes have reached 85% or higher seat allocation:{' '}
                        <b>{highCapacityRoutes.map((r) => `${r.routeNumber} (${routeOccupancy[r.id].count}/${r.capacity} seats)`).join(', ')}</b>.
                        {currentUser.role === 'admin'
                          ? ' Consider dispatching an auxiliary bus or limiting new seat approvals for these corridors.'
                          : ' Please arrive 5 minutes early at your boarding stop to avoid delays.'}
                      </p>
                    </div>
                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => setShowAddRouteModal(true)}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg shadow-sm"
                      >
                        Deploy Bus
                      </button>
                    )}
                  </div>
                )}

                {/* Top Stat Metrics */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex justify-between items-center text-xs text-slate-500 font-semibold mb-2">
                      <span>Total Active Routes</span>
                      <Bus size={18} className="text-indigo-600" />
                    </div>
                    <div className="text-2xl font-black text-slate-900">{routes.length} Corridors</div>
                    <span className="text-[11px] text-emerald-600 font-semibold">100% Fleet Operational</span>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex justify-between items-center text-xs text-slate-500 font-semibold mb-2">
                      <span>Total Bus Passes</span>
                      <QrCode size={18} className="text-purple-600" />
                    </div>
                    <div className="text-2xl font-black text-slate-900">{passes.length} Verified</div>
                    <span className="text-[11px] text-slate-500 font-medium">Digital QR Enabled</span>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex justify-between items-center text-xs text-slate-500 font-semibold mb-2">
                      <span>Pending Applications</span>
                      <Clock size={18} className="text-amber-600" />
                    </div>
                    <div className="text-2xl font-black text-amber-600">
                      {applications.filter((a) => a.status === 'pending').length}
                    </div>
                    <span className="text-[11px] text-slate-500 font-medium">Under transport review</span>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex justify-between items-center text-xs text-slate-500 font-semibold mb-2">
                      <span>Fleet Capacity Utilization</span>
                      <Users size={18} className="text-emerald-600" />
                    </div>
                    <div className="text-2xl font-black text-slate-900">
                      {Math.round(
                        (applications.filter((a) => a.status === 'approved').length /
                          routes.reduce((acc, r) => acc + r.capacity, 0)) *
                          100
                      )}%
                    </div>
                    <span className="text-[11px] text-slate-500 font-medium">Avg Occupancy Ratio</span>
                  </div>
                </div>

                {/* If Student: Show their Application Status banner */}
                {currentUser.role === 'student' && (
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
                    <h3 className="font-bold text-base text-slate-900 mb-4 flex items-center justify-between">
                      <span>Your Bus Pass Application Status</span>
                      {myApplication && (
                        <span
                          className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase ${
                            myApplication.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : myApplication.status === 'rejected'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {myApplication.status}
                        </span>
                      )}
                    </h3>

                    {myApplication ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs">
                          <div>
                            <span className="text-slate-500 block">Corridor / Route</span>
                            <span className="font-bold text-slate-800 text-sm">
                              {myApplication.routeNumber} ({myApplication.routeName})
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-500 block">Boarding Stop</span>
                            <span className="font-bold text-slate-800 text-sm">{myApplication.stopName}</span>
                          </div>
                          <div>
                            <span className="text-slate-500 block">Fee Status</span>
                            <span
                              className={`font-bold uppercase ${
                                myApplication.feeStatus === 'paid' ? 'text-emerald-600' : 'text-amber-600'
                              }`}
                            >
                              {myApplication.feeStatus} (₹{myApplication.feeAmount.toLocaleString()})
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-500 block">Application ID</span>
                            <span className="font-mono text-slate-600">{myApplication.id}</span>
                          </div>
                        </div>

                        {/* Actions according to status */}
                        {myApplication.status === 'approved' && myApplication.feeStatus === 'unpaid' && (
                          <div className="flex items-center justify-between p-4 bg-indigo-50 border border-indigo-200 rounded-2xl">
                            <div>
                              <h4 className="font-bold text-sm text-indigo-950">
                                Application Approved! Complete Payment to Activate Pass
                              </h4>
                              <p className="text-xs text-indigo-700">
                                Pay online via UPI/Card to instantly receive your digital pass with QR code.
                              </p>
                            </div>
                            <button
                              onClick={() => setPayingApplication(myApplication)}
                              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition"
                            >
                              Pay ₹{myApplication.feeAmount.toLocaleString()} Now
                            </button>
                          </div>
                        )}

                        {myApplication.status === 'approved' && myApplication.feeStatus === 'paid' && myPass && (
                          <div className="flex items-center justify-between p-4 bg-emerald-50 border border-emerald-200 rounded-2xl">
                            <div className="flex items-center gap-3">
                              <CheckCircle2 size={24} className="text-emerald-600" />
                              <div>
                                <h4 className="font-bold text-sm text-emerald-950">
                                  Your Bus Pass is Active & Verified!
                                </h4>
                                <p className="text-xs text-emerald-700">
                                  Pass #{myPass.id} is valid through {myPass.validUntil}.
                                </p>
                              </div>
                            </div>
                            <button
                              onClick={() => setViewingPass(myPass)}
                              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition"
                            >
                              Open Digital Pass
                            </button>
                          </div>
                        )}

                        {myApplication.status === 'pending' && (
                          <div className="flex items-center gap-3 p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 text-xs">
                            <Clock size={20} className="text-amber-600 flex-shrink-0" />
                            <span>
                              Your application was submitted on <b>{myApplication.appliedAt}</b>. Transport Admin is reviewing route seat allocation. You will receive an approval notification here soon.
                            </span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-6 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                        <Bus size={32} className="mx-auto text-slate-400 mb-2" />
                        <h4 className="font-bold text-slate-800 text-sm">No Active Bus Pass Found</h4>
                        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                          You haven't applied for a semester bus pass yet. Choose your corridor and boarding stop now.
                        </p>
                        <button
                          onClick={() => setActiveTab('apply')}
                          className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow transition"
                        >
                          Apply for Pass
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Route-Wise Capacity Breakdown */}
                <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-bold text-base text-slate-900">
                        Route-Wise Capacity & Seat Occupancy
                      </h3>
                      <p className="text-xs text-slate-500">
                        Live headcount per route to prevent bus overcrowding
                      </p>
                    </div>
                    {currentUser.role === 'admin' && (
                      <button
                        onClick={() => setShowAddRouteModal(true)}
                        className="text-xs text-indigo-600 hover:text-indigo-800 font-bold"
                      >
                        + Add Route
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {routes.map((route) => {
                      const stats = routeOccupancy[route.id] || { count: 0, capacity: route.capacity, pct: 0 };
                      const isHigh = stats.pct >= 85;
                      const isFull = stats.count >= stats.capacity;

                      return (
                        <div
                          key={route.id}
                          className={`p-4 rounded-2xl border transition ${
                            isFull
                              ? 'bg-red-50/50 border-red-300'
                              : isHigh
                              ? 'bg-amber-50/50 border-amber-300'
                              : 'bg-slate-50 border-slate-200'
                          }`}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="bg-indigo-600 text-white text-[11px] font-extrabold px-2 py-0.5 rounded-lg">
                                  {route.routeNumber}
                                </span>
                                <span className="font-bold text-sm text-slate-900">{route.name}</span>
                              </div>
                              <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                                <span>Bus #{route.busNumber}</span>
                                <span>•</span>
                                <span>Driver: {route.driverName}</span>
                              </div>
                            </div>

                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                isFull
                                  ? 'bg-red-200 text-red-900'
                                  : isHigh
                                  ? 'bg-amber-200 text-amber-900'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {isFull ? 'FULL' : isHigh ? 'NEAR CAPACITY' : 'SEATS AVAILABLE'}
                            </span>
                          </div>

                          {/* Progress Bar */}
                          <div className="space-y-1.5 mt-3">
                            <div className="flex justify-between text-xs font-semibold">
                              <span className="text-slate-600">
                                Allocated: <b>{stats.count}</b> of {route.capacity} seats
                              </span>
                              <span
                                className={
                                  isFull
                                    ? 'text-red-700 font-bold'
                                    : isHigh
                                    ? 'text-amber-700 font-bold'
                                    : 'text-indigo-700'
                                }
                              >
                                {stats.pct}% Full
                              </span>
                            </div>
                            <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all duration-300 ${
                                  isFull
                                    ? 'bg-red-600'
                                    : isHigh
                                    ? 'bg-amber-500'
                                    : 'bg-indigo-600'
                                }`}
                                style={{ width: `${Math.min(stats.pct, 100)}%` }}
                              />
                            </div>
                          </div>

                          <div className="mt-3 pt-2 border-t border-slate-200/60 flex justify-between text-[11px] text-slate-500">
                            <span>Pickup: {route.morningDeparture}</span>
                            <span>Fee: ₹{route.fee.toLocaleString()} / sem</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* STUDENT APPLY FOR PASS TAB */}
            {activeTab === 'apply' && currentUser.role === 'student' && (
              <div className="max-w-2xl mx-auto bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
                <div>
                  <h3 className="text-xl font-black text-slate-900">Apply for Student Bus Pass</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Select your commuting corridor and boarding stop for the upcoming semester.
                  </p>
                </div>

                {applySuccess ? (
                  <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2 animate-in zoom-in-95 duration-150">
                    <CheckCircle2 size={40} className="text-emerald-600 mx-auto" />
                    <h4 className="font-black text-base text-emerald-950">Application Submitted!</h4>
                    <p className="text-xs text-emerald-800">
                      Your pass request has been sent to the Transport Office for verification.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleApply} className="space-y-4">
                    {/* Student Info Readonly Preview */}
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-slate-500 block">Student Name</span>
                        <span className="font-bold text-slate-800">{currentUser.name}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Roll Number</span>
                        <span className="font-bold text-slate-800">{currentUser.rollNumber || '22CS089'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Department</span>
                        <span className="font-bold text-slate-800">{currentUser.department || 'Engineering'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Academic Year</span>
                        <span className="font-bold text-slate-800">{currentUser.year || '3rd Year'}</span>
                      </div>
                    </div>

                    {/* Choose Route */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        1. Select Bus Route & Corridor
                      </label>
                      <select
                        value={applyRouteId}
                        onChange={(e) => setApplyRouteId(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:border-indigo-600 focus:bg-white outline-none"
                      >
                        {routes.map((r) => {
                          const occ = routeOccupancy[r.id] || { count: 0, capacity: r.capacity, pct: 0 };
                          return (
                            <option key={r.id} value={r.id} disabled={occ.count >= occ.capacity}>
                              {r.routeNumber} — {r.name} (Bus {r.busNumber}) • ₹{r.fee.toLocaleString()} {occ.count >= occ.capacity ? '[FULL]' : `[${occ.capacity - occ.count} seats left]`}
                            </option>
                          );
                        })}
                      </select>
                    </div>

                    {/* Choose Stop */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        2. Select Your Boarding Stop
                      </label>
                      <select
                        value={applyStopId}
                        onChange={(e) => setApplyStopId(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm focus:border-indigo-600 focus:bg-white outline-none"
                      >
                        {routes
                          .find((r) => r.id === applyRouteId)
                          ?.stops.map((s) => (
                            <option key={s.id} value={s.id}>
                              📍 {s.name} (Pickup: {s.pickupTime} • Return Drop: {s.dropTime})
                            </option>
                          ))}
                      </select>
                    </div>

                    {/* Transport Guidelines Checkbox */}
                    <div className="bg-indigo-50/70 p-3.5 rounded-2xl border border-indigo-200 text-xs text-indigo-900 space-y-1">
                      <label className="flex items-start gap-2 cursor-pointer font-medium">
                        <input type="checkbox" required defaultChecked className="mt-0.5 rounded text-indigo-600" />
                        <span>
                          I agree to abide by the College Transport Rules. I understand that the bus pass is non-transferable and seat allocation is subject to capacity.
                        </span>
                      </label>
                    </div>

                    <div className="flex gap-3 pt-2">
                      <button
                        type="submit"
                        className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl shadow-md transition"
                      >
                        Submit Pass Application
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveTab('overview')}
                        className="px-5 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* MY DIGITAL PASS TAB */}
            {activeTab === 'pass' && currentUser.role === 'student' && (
              <div className="space-y-6">
                {myPass ? (
                  <div>
                    <div className="text-center mb-6">
                      <h3 className="text-2xl font-black text-slate-900">Your Official Digital Bus Pass</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Present this pass to the bus conductor upon boarding. QR code updates automatically.
                      </p>
                    </div>
                    <DigitalPassCard pass={myPass} />
                  </div>
                ) : (
                  <div className="max-w-md mx-auto text-center py-12 bg-white rounded-3xl border border-slate-200 p-8">
                    <QrCode size={40} className="mx-auto text-slate-400 mb-3" />
                    <h4 className="font-bold text-base text-slate-800">No Active Pass Issued</h4>
                    <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                      {myApplication?.status === 'approved'
                        ? 'Your application is approved! Please complete the fee payment to generate your pass.'
                        : myApplication?.status === 'pending'
                        ? 'Your application is currently pending admin approval.'
                        : 'You need to apply for a pass before viewing your digital ID card.'}
                    </p>
                    <button
                      onClick={() => setActiveTab(myApplication?.status === 'approved' ? 'overview' : 'apply')}
                      className="mt-4 px-4 py-2 bg-indigo-600 text-white font-bold text-xs rounded-xl shadow transition"
                    >
                      {myApplication?.status === 'approved' ? 'Proceed to Payment' : 'Apply Now'}
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* ADMIN APPLICATIONS MANAGEMENT TAB */}
            {activeTab === 'applications' && currentUser.role === 'admin' && (
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-black text-lg text-slate-900">
                      Student Bus Pass Applications ({applications.length})
                    </h3>
                    <p className="text-xs text-slate-500">
                      Approve or reject route choices, verify fee payments, and issue digital passes
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search size={14} className="absolute left-3 top-3 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Search student or roll..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="bg-slate-50 border border-slate-300 rounded-xl pl-8 pr-3 py-1.5 text-xs focus:border-indigo-600 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Filter tabs */}
                <div className="flex gap-2 overflow-x-auto pb-1 text-xs font-semibold">
                  {(['all', 'pending', 'approved', 'unpaid', 'rejected'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setAppFilter(filter)}
                      className={`px-3 py-1.5 rounded-xl capitalize transition ${
                        appFilter === filter
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {filter} (
                      {filter === 'all'
                        ? applications.length
                        : filter === 'unpaid'
                        ? applications.filter((a) => a.status === 'approved' && a.feeStatus === 'unpaid').length
                        : applications.filter((a) => a.status === filter).length}
                      )
                    </button>
                  ))}
                </div>

                {/* Applications Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider">
                        <th className="p-3">Student Details</th>
                        <th className="p-3">Corridor & Stop</th>
                        <th className="p-3">Status</th>
                        <th className="p-3">Fee Status</th>
                        <th className="p-3">Applied On</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredApps.map((app) => (
                        <tr key={app.id} className="hover:bg-slate-50 transition">
                          <td className="p-3">
                            <div className="flex items-center gap-2.5">
                              <img
                                src={app.photoUrl}
                                alt={app.studentName}
                                className="w-8 h-8 rounded-full object-cover border border-slate-200"
                              />
                              <div>
                                <span className="font-bold text-slate-900 block">{app.studentName}</span>
                                <span className="font-mono text-[11px] text-slate-500">
                                  {app.rollNumber} • {app.department}
                                </span>
                              </div>
                            </div>
                          </td>

                          <td className="p-3">
                            <span className="font-bold text-slate-800 block">
                              {app.routeNumber} ({app.routeName})
                            </span>
                            <span className="text-slate-500 text-[11px]">📍 {app.stopName}</span>
                          </td>

                          <td className="p-3">
                            <span
                              className={`inline-block px-2 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                                app.status === 'approved'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : app.status === 'rejected'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {app.status}
                            </span>
                          </td>

                          <td className="p-3">
                            <span
                              className={`font-semibold uppercase text-[11px] ${
                                app.feeStatus === 'paid' ? 'text-emerald-700' : 'text-amber-700'
                              }`}
                            >
                              {app.feeStatus} (₹{app.feeAmount.toLocaleString()})
                            </span>
                            {app.transactionId && (
                              <span className="block text-[10px] font-mono text-slate-400">
                                {app.transactionId}
                              </span>
                            )}
                          </td>

                          <td className="p-3 text-slate-500 text-[11px]">{app.appliedAt}</td>

                          <td className="p-3 text-right space-x-1">
                            {app.status === 'pending' && (
                              <>
                                <button
                                  onClick={() => handleUpdateAppStatus(app.id, 'approved')}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleUpdateAppStatus(app.id, 'rejected', 'Route capacity full')}
                                  className="px-2.5 py-1 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg font-bold text-[11px] transition"
                                >
                                  Reject
                                </button>
                              </>
                            )}

                            {app.status === 'approved' && app.feeStatus === 'unpaid' && (
                              <button
                                onClick={() => handlePaymentSuccess(app.id, 'CASH-REC-' + Date.now(), 'Cash / Office Challan')}
                                className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg font-bold text-[11px] transition"
                                title="Record offline challan / cash fee payment"
                              >
                                Mark Paid (Cash)
                              </button>
                            )}

                            {app.passId && (
                              <button
                                onClick={() => {
                                  const p = passes.find((x) => x.id === app.passId);
                                  if (p) setViewingPass(p);
                                }}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold text-[11px] transition"
                              >
                                View Pass
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ADMIN FLEET & ROUTE MANAGER */}
            {activeTab === 'fleet' && currentUser.role === 'admin' && (
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-black text-lg text-slate-900">
                      Fleet Logistics & Route Management
                    </h3>
                    <p className="text-xs text-slate-500">
                      Configure bus corridors, driver contacts, seat limits, and fee schedules
                    </p>
                  </div>
                  <button
                    onClick={() => setShowAddRouteModal(true)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5"
                  >
                    <Plus size={15} /> Add Bus Route
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {routes.map((route) => {
                    const occ = routeOccupancy[route.id] || { count: 0, capacity: route.capacity, pct: 0 };
                    return (
                      <div key={route.id} className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="bg-slate-900 text-white text-xs font-mono font-bold px-2.5 py-0.5 rounded-lg">
                                {route.routeNumber}
                              </span>
                              <h4 className="font-bold text-base text-slate-900">{route.name}</h4>
                            </div>
                            <span className="text-xs text-indigo-700 font-semibold mt-1 block">
                              Bus Reg: {route.busNumber}
                            </span>
                          </div>
                          <span className="font-black text-sm text-slate-900">
                            ₹{route.fee.toLocaleString()} <span className="text-[10px] text-slate-500 font-normal">/ sem</span>
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs bg-white p-3 rounded-xl border border-slate-200">
                          <div>
                            <span className="text-slate-500 text-[11px] block">Driver in Charge</span>
                            <span className="font-bold text-slate-800">{route.driverName}</span>
                            <span className="text-[11px] text-slate-500 block">{route.driverPhone}</span>
                          </div>
                          <div>
                            <span className="text-slate-500 text-[11px] block">Seat Allocation</span>
                            <span className="font-bold text-slate-800">{occ.count} / {route.capacity} seats</span>
                            <span className="text-[11px] text-indigo-600 block">{occ.pct}% allocated</span>
                          </div>
                        </div>

                        <div>
                          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                            Scheduled Stops ({route.stops.length})
                          </span>
                          <div className="space-y-1">
                            {route.stops.map((st, idx) => (
                              <div key={st.id} className="flex justify-between text-xs text-slate-600">
                                <span>{idx + 1}. {st.name}</span>
                                <span className="font-mono text-slate-400 text-[11px]">{st.pickupTime}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ROUTE TIMINGS & SCHEDULES (Accessible to everyone) */}
            {activeTab === 'routes' && (
              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-6">
                <div>
                  <h3 className="font-black text-xl text-slate-900">
                    College Bus Timetables & Boarding Points
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Morning pickups start between 7:00 AM – 7:20 AM. Buses reach college main gate by 8:20 AM.
                    Evening departure is at 4:45 PM sharp from Central Bay.
                  </p>
                </div>

                <div className="space-y-4">
                  {routes.map((route) => (
                    <div key={route.id} className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <span className="bg-indigo-600 text-white font-extrabold text-xs px-2.5 py-1 rounded-lg">
                            {route.routeNumber}
                          </span>
                          <div>
                            <h4 className="font-bold text-base text-slate-900">{route.name}</h4>
                            <span className="text-xs text-slate-500">
                              Bus {route.busNumber} • Driver: {route.driverName} ({route.driverPhone})
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 text-xs">
                          <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md font-semibold">
                            Morning: {route.morningDeparture}
                          </span>
                          <span className="bg-purple-100 text-purple-800 px-2 py-0.5 rounded-md font-semibold">
                            Evening: {route.eveningDeparture}
                          </span>
                        </div>
                      </div>

                      {/* Stops list */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 pt-2">
                        {route.stops.map((st, idx) => (
                          <div key={st.id} className="bg-white p-2.5 rounded-xl border border-slate-200 text-xs">
                            <div className="flex items-center gap-1.5 text-indigo-700 font-bold mb-0.5">
                              <MapPin size={12} />
                              <span className="truncate">Stop #{idx + 1}</span>
                            </div>
                            <div className="font-semibold text-slate-800 truncate">{st.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                              Pickup: {st.pickupTime}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Floating Integrated AI Chatbot Widget */}
      <AiChatbot onSelectAction={(act) => console.log('Action:', act)} />

      {/* Conductor QR Code Scanner Modal */}
      {showQrModal && (
        <QrVerificationModal passes={passes} onClose={() => setShowQrModal(false)} />
      )}

      {/* Digital Pass View Modal */}
      {viewingPass && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full">
            <DigitalPassCard pass={viewingPass} onClose={() => setViewingPass(null)} />
          </div>
        </div>
      )}

      {/* Payment Gateway Modal */}
      {payingApplication && (
        <PaymentModal
          application={payingApplication}
          onPaymentSuccess={(txn, method) => {
            handlePaymentSuccess(payingApplication.id, txn, method);
          }}
          onClose={() => setPayingApplication(null)}
        />
      )}

      {/* Database Schema & Architecture Modal */}
      {showArchModal && <ArchitectureModal onClose={() => setShowArchModal(false)} />}

      {/* Admin Add Route Modal */}
      {showAddRouteModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden border border-slate-200">
            <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white p-5 flex items-center justify-between">
              <h3 className="font-bold text-base text-white">Add New Bus Route</h3>
              <button onClick={() => setShowAddRouteModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            <form onSubmit={handleAddRoute} className="p-6 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Route Number</label>
                  <input
                    required
                    placeholder="e.g. R-05"
                    value={newRouteNum}
                    onChange={(e) => setNewRouteNum(e.target.value)}
                    className="w-full bg-slate-50 border rounded-xl p-2 outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Bus Number</label>
                  <input
                    required
                    placeholder="KA-01-F-9999"
                    value={newBusNum}
                    onChange={(e) => setNewBusNum(e.target.value)}
                    className="w-full bg-slate-50 border rounded-xl p-2 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Route Corridor Name</label>
                <input
                  required
                  placeholder="e.g. West Airport Road Express"
                  value={newRouteName}
                  onChange={(e) => setNewRouteName(e.target.value)}
                  className="w-full bg-slate-50 border rounded-xl p-2 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Driver Name</label>
                  <input
                    placeholder="e.g. Anand Gowda"
                    value={newDriverName}
                    onChange={(e) => setNewDriverName(e.target.value)}
                    className="w-full bg-slate-50 border rounded-xl p-2 outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Driver Phone</label>
                  <input
                    placeholder="+91 98765 00000"
                    value={newDriverPhone}
                    onChange={(e) => setNewDriverPhone(e.target.value)}
                    className="w-full bg-slate-50 border rounded-xl p-2 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Seat Capacity</label>
                  <input
                    type="number"
                    value={newCapacity}
                    onChange={(e) => setNewCapacity(e.target.value)}
                    className="w-full bg-slate-50 border rounded-xl p-2 outline-none"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Semester Fee (₹)</label>
                  <input
                    type="number"
                    value={newFee}
                    onChange={(e) => setNewFee(e.target.value)}
                    className="w-full bg-slate-50 border rounded-xl p-2 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Boarding Stops (Comma Separated)</label>
                <textarea
                  rows={2}
                  value={newStopsText}
                  onChange={(e) => setNewStopsText(e.target.value)}
                  placeholder="Stop 1, Stop 2, Stop 3"
                  className="w-full bg-slate-50 border rounded-xl p-2 outline-none text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl"
                >
                  Create Route
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddRouteModal(false)}
                  className="px-4 py-2.5 bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
