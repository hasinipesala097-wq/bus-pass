export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: 'student' | 'admin';
  rollNumber?: string;
  department?: string;
  year?: string;
  phone?: string;
  avatar?: string;
}

export interface Stop {
  id: string;
  name: string;
  pickupTime: string;
  dropTime: string;
  landmark?: string;
}

export interface BusRoute {
  id: string;
  routeNumber: string; // e.g. R-01
  name: string;
  busNumber: string;
  driverName: string;
  driverPhone: string;
  morningDeparture: string;
  eveningDeparture: string;
  capacity: number;
  fee: number;
  stops: Stop[];
}

export type ApplicationStatus = 'pending' | 'approved' | 'rejected';
export type PaymentStatus = 'paid' | 'unpaid';

export interface PassApplication {
  id: string;
  studentId: string;
  studentName: string;
  rollNumber: string;
  department: string;
  year: string;
  phone: string;
  email: string;
  photoUrl: string;
  routeId: string;
  routeNumber: string;
  routeName: string;
  busNumber: string;
  stopId: string;
  stopName: string;
  status: ApplicationStatus;
  feeStatus: PaymentStatus;
  feeAmount: number;
  paymentMethod?: string;
  transactionId?: string;
  appliedAt: string;
  approvedAt?: string;
  adminRemarks?: string;
  passId?: string;
}

export interface DigitalBusPass {
  id: string; // e.g. PASS-2026-9041
  applicationId: string;
  studentId: string;
  studentName: string;
  rollNumber: string;
  department: string;
  year: string;
  phone: string;
  photoUrl: string;
  routeNumber: string;
  routeName: string;
  busNumber: string;
  stopName: string;
  issueDate: string;
  validUntil: string;
  status: 'active' | 'revoked' | 'expired';
  qrData: string;
  qrCodeUrl?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedAction?: string;
}
