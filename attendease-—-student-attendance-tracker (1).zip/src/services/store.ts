import { BusRoute, PassApplication, DigitalBusPass, User } from '../types';
import QRCode from 'qrcode';

export const INITIAL_USERS: User[] = [
  {
    id: 'u-admin-1',
    name: 'Prof. Ramesh Kulkarni',
    email: 'admin@transport.edu',
    password: 'admin',
    role: 'admin',
    phone: '+91 94481 22334',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'u-student-1',
    name: 'Aarav Sharma',
    email: 'student@college.edu',
    password: '1234',
    role: 'student',
    rollNumber: '22CS089',
    department: 'Computer Science & Engg',
    year: '3rd Year (VI Sem)',
    phone: '+91 98765 11223',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'u-student-2',
    name: 'Priya Nambiar',
    email: 'priya@college.edu',
    password: '1234',
    role: 'student',
    rollNumber: '23EC042',
    department: 'Electronics & Comm',
    year: '2nd Year (IV Sem)',
    phone: '+91 97412 88776',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80'
  }
];

export const INITIAL_ROUTES: BusRoute[] = [
  {
    id: 'r1',
    routeNumber: 'R-01',
    name: 'North Campus Express',
    busNumber: 'KA-01-F-2345',
    driverName: 'Rajesh Kumar',
    driverPhone: '+91 98765 43210',
    morningDeparture: '07:15 AM',
    eveningDeparture: '04:45 PM',
    capacity: 45,
    fee: 14000,
    stops: [
      { id: 'st1', name: 'Hebbal Flyover Junction', pickupTime: '07:15 AM', dropTime: '05:30 PM' },
      { id: 'st2', name: 'Nagawara Ring Road', pickupTime: '07:30 AM', dropTime: '05:15 PM' },
      { id: 'st3', name: 'Hennur Cross', pickupTime: '07:45 AM', dropTime: '05:00 PM' },
      { id: 'st4', name: 'College Main Gate', pickupTime: '08:20 AM', dropTime: '04:45 PM' }
    ]
  },
  {
    id: 'r2',
    routeNumber: 'R-02',
    name: 'Metro Line Corridor',
    busNumber: 'KA-01-F-3412',
    driverName: 'Venkatesh Rao',
    driverPhone: '+91 98451 12345',
    morningDeparture: '07:05 AM',
    eveningDeparture: '04:45 PM',
    capacity: 50,
    fee: 15500,
    stops: [
      { id: 'st5', name: 'Majestic Metro Terminal', pickupTime: '07:05 AM', dropTime: '05:40 PM' },
      { id: 'st6', name: 'Malleshwaram 8th Cross', pickupTime: '07:20 AM', dropTime: '05:25 PM' },
      { id: 'st7', name: 'Yeshwantpur Circle', pickupTime: '07:35 AM', dropTime: '05:10 PM' },
      { id: 'st8', name: 'College Main Gate', pickupTime: '08:15 AM', dropTime: '04:45 PM' }
    ]
  },
  {
    id: 'r3',
    routeNumber: 'R-03',
    name: 'South Hills & IT Corridor',
    busNumber: 'KA-01-F-5689',
    driverName: 'Mohammad Altaf',
    driverPhone: '+91 99002 98765',
    morningDeparture: '07:00 AM',
    eveningDeparture: '04:45 PM',
    capacity: 38, // intentionally close to capacity for testing Live Alert!
    fee: 16000,
    stops: [
      { id: 'st9', name: 'Silk Board Junction', pickupTime: '07:00 AM', dropTime: '05:45 PM' },
      { id: 'st10', name: 'HSR Layout 27th Main', pickupTime: '07:18 AM', dropTime: '05:30 PM' },
      { id: 'st11', name: 'Bellandur EcoSpace', pickupTime: '07:35 AM', dropTime: '05:15 PM' },
      { id: 'st12', name: 'College Main Gate', pickupTime: '08:25 AM', dropTime: '04:45 PM' }
    ]
  },
  {
    id: 'r4',
    routeNumber: 'R-04',
    name: 'East Suburb Connector',
    busNumber: 'KA-01-F-7821',
    driverName: 'Girish Reddy',
    driverPhone: '+91 97314 65432',
    morningDeparture: '07:20 AM',
    eveningDeparture: '04:45 PM',
    capacity: 45,
    fee: 13500,
    stops: [
      { id: 'st13', name: 'Whitefield TTMC', pickupTime: '07:20 AM', dropTime: '05:25 PM' },
      { id: 'st14', name: 'KR Puram Railway Station', pickupTime: '07:40 AM', dropTime: '05:05 PM' },
      { id: 'st15', name: 'Ramamurthy Nagar', pickupTime: '07:55 AM', dropTime: '04:55 PM' },
      { id: 'st16', name: 'College Main Gate', pickupTime: '08:20 AM', dropTime: '04:45 PM' }
    ]
  }
];

export const INITIAL_APPLICATIONS: PassApplication[] = [
  {
    id: 'app-101',
    studentId: 'u-student-1',
    studentName: 'Aarav Sharma',
    rollNumber: '22CS089',
    department: 'Computer Science & Engg',
    year: '3rd Year (VI Sem)',
    phone: '+91 98765 11223',
    email: 'student@college.edu',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    routeId: 'r1',
    routeNumber: 'R-01',
    routeName: 'North Campus Express',
    busNumber: 'KA-01-F-2345',
    stopId: 'st2',
    stopName: 'Nagawara Ring Road',
    status: 'approved',
    feeStatus: 'paid',
    feeAmount: 14000,
    paymentMethod: 'UPI (Google Pay)',
    transactionId: 'TXN-904128834',
    appliedAt: '2026-09-15',
    approvedAt: '2026-09-16',
    passId: 'PASS-2026-8901'
  },
  {
    id: 'app-102',
    studentId: 'u-student-2',
    studentName: 'Priya Nambiar',
    rollNumber: '23EC042',
    department: 'Electronics & Comm',
    year: '2nd Year (IV Sem)',
    phone: '+91 97412 88776',
    email: 'priya@college.edu',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    routeId: 'r2',
    routeNumber: 'R-02',
    routeName: 'Metro Line Corridor',
    busNumber: 'KA-01-F-3412',
    stopId: 'st6',
    stopName: 'Malleshwaram 8th Cross',
    status: 'approved',
    feeStatus: 'unpaid',
    feeAmount: 15500,
    appliedAt: '2026-10-01',
    approvedAt: '2026-10-02'
  },
  {
    id: 'app-103',
    studentId: 'u-student-3',
    studentName: 'Rohan Deshmukh',
    rollNumber: '24ME015',
    department: 'Mechanical Engg',
    year: '1st Year (II Sem)',
    phone: '+91 98440 33445',
    email: 'rohan.d@college.edu',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    routeId: 'r3',
    routeNumber: 'R-03',
    routeName: 'South Hills & IT Corridor',
    busNumber: 'KA-01-F-5689',
    stopId: 'st10',
    stopName: 'HSR Layout 27th Main',
    status: 'pending',
    feeStatus: 'unpaid',
    feeAmount: 16000,
    appliedAt: '2026-10-04'
  }
];

export const INITIAL_PASSES: DigitalBusPass[] = [
  {
    id: 'PASS-2026-8901',
    applicationId: 'app-101',
    studentId: 'u-student-1',
    studentName: 'Aarav Sharma',
    rollNumber: '22CS089',
    department: 'Computer Science & Engg',
    year: '3rd Year (VI Sem)',
    phone: '+91 98765 11223',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    routeNumber: 'R-01',
    routeName: 'North Campus Express',
    busNumber: 'KA-01-F-2345',
    stopName: 'Nagawara Ring Road',
    issueDate: '2026-09-16',
    validUntil: '2027-03-31',
    status: 'active',
    qrData: JSON.stringify({
      passId: 'PASS-2026-8901',
      student: 'Aarav Sharma',
      roll: '22CS089',
      route: 'R-01 (North Campus Express)',
      bus: 'KA-01-F-2345',
      stop: 'Nagawara Ring Road',
      validUntil: '2027-03-31',
      status: 'VERIFIED_ACTIVE'
    })
  }
];

export async function generateQrDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      width: 260,
      margin: 1.5,
      color: {
        dark: '#0f172a',
        light: '#ffffff'
      }
    });
  } catch (err) {
    console.error('Error generating QR code:', err);
    return '';
  }
}
