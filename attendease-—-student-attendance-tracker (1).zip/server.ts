import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Initialize Google GenAI
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Initial Mock Seed Data for Server
const initialRoutes = [
  {
    id: 'r1',
    routeNumber: 'R-01',
    name: 'North Campus Express',
    busNumber: 'KA-01-F-2345',
    driverName: 'Rajesh Kumar',
    driverPhone: '+91 98765 43210',
    morningDeparture: '07:15 AM',
    eveningDeparture: '04:45 PM',
    capacity: 45,
    fee: 14000,
    stops: [
      { id: 'st1', name: 'Hebbal Flyover Junction', pickupTime: '07:15 AM', dropTime: '05:30 PM' },
      { id: 'st2', name: 'Nagawara Ring Road', pickupTime: '07:30 AM', dropTime: '05:15 PM' },
      { id: 'st3', name: 'Hennur Cross', pickupTime: '07:45 AM', dropTime: '05:00 PM' },
      { id: 'st4', name: 'College Main Gate', pickupTime: '08:20 AM', dropTime: '04:45 PM' }
    ]
  },
  {
    id: 'r2',
    routeNumber: 'R-02',
    name: 'Metro Line Corridor',
    busNumber: 'KA-01-F-3412',
    driverName: 'Venkatesh Rao',
    driverPhone: '+91 98451 12345',
    morningDeparture: '07:05 AM',
    eveningDeparture: '04:45 PM',
    capacity: 50,
    fee: 15500,
    stops: [
      { id: 'st5', name: 'Majestic Metro Terminal', pickupTime: '07:05 AM', dropTime: '05:40 PM' },
      { id: 'st6', name: 'Malleshwaram 8th Cross', pickupTime: '07:20 AM', dropTime: '05:25 PM' },
      { id: 'st7', name: 'Yeshwantpur Circle', pickupTime: '07:35 AM', dropTime: '05:10 PM' },
      { id: 'st8', name: 'College Main Gate', pickupTime: '08:15 AM', dropTime: '04:45 PM' }
    ]
  },
  {
    id: 'r3',
    routeNumber: 'R-03',
    name: 'South Hills & IT Corridor',
    busNumber: 'KA-01-F-5689',
    driverName: 'Mohammad Altaf',
    driverPhone: '+91 99002 98765',
    morningDeparture: '07:00 AM',
    eveningDeparture: '04:45 PM',
    capacity: 40,
    fee: 16000,
    stops: [
      { id: 'st9', name: 'Silk Board Junction', pickupTime: '07:00 AM', dropTime: '05:45 PM' },
      { id: 'st10', name: 'HSR Layout 27th Main', pickupTime: '07:18 AM', dropTime: '05:30 PM' },
      { id: 'st11', name: 'Bellandur EcoSpace', pickupTime: '07:35 AM', dropTime: '05:15 PM' },
      { id: 'st12', name: 'College Main Gate', pickupTime: '08:25 AM', dropTime: '04:45 PM' }
    ]
  },
  {
    id: 'r4',
    routeNumber: 'R-04',
    name: 'East Suburb Connector',
    busNumber: 'KA-01-F-7821',
    driverName: 'Girish Reddy',
    driverPhone: '+91 97314 65432',
    morningDeparture: '07:20 AM',
    eveningDeparture: '04:45 PM',
    capacity: 45,
    fee: 13500,
    stops: [
      { id: 'st13', name: 'Whitefield TTMC', pickupTime: '07:20 AM', dropTime: '05:25 PM' },
      { id: 'st14', name: 'KR Puram Railway Station', pickupTime: '07:40 AM', dropTime: '05:05 PM' },
      { id: 'st15', name: 'Ramamurthy Nagar', pickupTime: '07:55 AM', dropTime: '04:55 PM' },
      { id: 'st16', name: 'College Main Gate', pickupTime: '08:20 AM', dropTime: '04:45 PM' }
    ]
  }
];

// In-memory data store for server side state (mirrors database)
let serverRoutes = [...initialRoutes];

// AI Chatbot Knowledge Base Prompt
const SYSTEM_INSTRUCTION = `You are "CampusRide AI", the official intelligent transport and bus pass assistant for the College Transport Management Office.
You assist students, parents, and faculty with bus pass applications, route schedules, bus timings, fees, rules, and live capacity tracking.

Here is the current College Transport System knowledge base:
1. Routes Available:
   - Route R-01 (North Campus Express, Bus # KA-01-F-2345): Stops include Hebbal Flyover (7:15 AM), Nagawara Ring Road (7:30 AM), Hennur Cross (7:45 AM). Fee: ₹14,000/sem. Capacity: 45. Driver: Rajesh Kumar (+91 98765 43210).
   - Route R-02 (Metro Line Corridor, Bus # KA-01-F-3412): Stops include Majestic Metro (7:05 AM), Malleshwaram 8th Cross (7:20 AM), Yeshwantpur Circle (7:35 AM). Fee: ₹15,500/sem. Capacity: 50. Driver: Venkatesh Rao (+91 98451 12345).
   - Route R-03 (South Hills & IT Corridor, Bus # KA-01-F-5689): Stops include Silk Board Junction (7:00 AM), HSR Layout (7:18 AM), Bellandur EcoSpace (7:35 AM). Fee: ₹16,000/sem. Capacity: 40. Driver: Mohammad Altaf (+91 99002 98765).
   - Route R-04 (East Suburb Connector, Bus # KA-01-F-7821): Stops include Whitefield TTMC (7:20 AM), KR Puram (7:40 AM), Ramamurthy Nagar (7:55 AM). Fee: ₹13,500/sem. Capacity: 45. Driver: Girish Reddy (+91 97314 65432).

2. General Rules & Policies:
   - Morning arrival at campus: 8:20 AM - 8:25 AM. Classes commence at 8:45 AM.
   - Evening departure from college: 4:45 PM sharp from Central Bus Bay.
   - Bus Pass Validity: Valid for 1 academic semester (6 months) from the date of issue.
   - Physical Pass vs Digital Pass: Conductor verifies passes via digital QR code scanner or printed pass with QR code.
   - Payment Methods: Online UPI, Debit/Credit Card, Net Banking or offline cash challan at Transport Office (Admin Block Ground Floor, Room 104).
   - Lost Pass Policy: Digital pass can be re-downloaded at any time from the Student Portal without any fee!
   - Overcrowding Policy: Each bus has a strict seat limit. If a route reaches 90%+ capacity, the system triggers a Live Capacity Alert and deploys an auxiliary bus.

Tone: Helpful, polite, fast, accurate, concise. Always format timings and stops clearly with bullet points. If asked something outside transport matters, politely redirect them back to college transportation.`;

// AI Chatbot Route
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    if (!aiClient) {
      // Fallback rule-based responses if API key is not supplied
      const lower = message.toLowerCase();
      let fallbackReply = "Hello! I am your CampusRide Transport Assistant. ";

      if (lower.includes('timing') || lower.includes('time') || lower.includes('schedule')) {
        fallbackReply = `🕒 **Bus Timings Summary:**
• **Morning Pickup:** Buses start between 7:00 AM - 7:20 AM and reach campus by 8:20 AM.
• **Evening Departure:** All buses depart from Central Bus Bay at 4:45 PM sharp.
• R-01 (Hebbal 7:15 AM), R-02 (Majestic 7:05 AM), R-03 (Silk Board 7:00 AM), R-04 (Whitefield 7:20 AM).`;
      } else if (lower.includes('fee') || lower.includes('cost') || lower.includes('price') || lower.includes('pay')) {
        fallbackReply = `💳 **Semester Bus Pass Fees:**
• R-01 North Campus: ₹14,000 / semester
• R-02 Metro Line: ₹15,500 / semester
• R-03 South Hills & IT: ₹16,000 / semester
• R-04 East Suburbs: ₹13,500 / semester
You can pay directly in the Student Portal via UPI/Card or at Admin Block Room 104.`;
      } else if (lower.includes('apply') || lower.includes('pass') || lower.includes('status')) {
        fallbackReply = `📋 **How to Apply for a Pass:**
1. Login to the Student Portal.
2. Click **Apply for Pass**, pick your Route & Boarding Stop.
3. Once approved by Transport Admin, proceed to **Pay Fee**.
4. Instantly view and download your **Digital Bus Pass with QR Code**!`;
      } else if (lower.includes('qr') || lower.includes('verify') || lower.includes('scan')) {
        fallbackReply = `📱 **QR Code Verification:**
Every digital pass has a cryptographic QR code containing Pass ID, Route Number, Student Roll, and Expiry Date. Bus conductors scan this QR code at boarding to verify active status.`;
      } else {
        fallbackReply = `👋 Hello! I can help you with:
• **Bus routes & boarding stops**
• **Morning pickup & evening drop timings**
• **Semester fee breakdown & payment modes**
• **Application approval status & QR verification**
• **Driver contact details & capacity alerts**
How can I assist you today?`;
      }

      res.json({ reply: fallbackReply });
      return;
    }

    // Call Gemini 3.8 Flash via @google/genai
    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: message,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    const reply = response.text || 'I could not generate an answer right now. Please try again.';
    res.json({ reply });
  } catch (error: any) {
    console.error('Gemini Chat API Error:', error);
    res.status(500).json({
      error: 'Failed to process AI chat response',
      details: error.message || 'Unknown error',
      reply: 'The transport assistant is momentarily unavailable. Please check the Route Timings section or contact Transport Admin at Room 104.'
    });
  }
});

// Route & System APIs
app.get('/api/routes', (_req: Request, res: Response) => {
  res.json({ routes: serverRoutes });
});

app.post('/api/routes', (req: Request, res: Response) => {
  const newRoute = {
    id: 'r' + Date.now(),
    ...req.body
  };
  serverRoutes.push(newRoute);
  res.status(201).json({ route: newRoute });
});

app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'CampusPass Transport API', timestamp: new Date().toISOString() });
});

// Vite Middleware for Development / Static for Production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CampusPass] Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
